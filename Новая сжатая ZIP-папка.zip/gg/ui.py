import customtkinter as ctk
import tkinter as tk
import threading
import queue
import time


# ==================== СОСТОЯНИЯ ====================
STATE_SLEEPING  = "sleeping"
STATE_LISTENING = "listening"
STATE_THINKING  = "thinking"
STATE_EXECUTING = "executing"

STATE_COLORS = {
    STATE_SLEEPING:  "#3a3a5c",
    STATE_LISTENING: "#7c5cff",
    STATE_THINKING:  "#ffb84d",
    STATE_EXECUTING: "#4dff88",
}

STATE_TEXTS = {
    STATE_SLEEPING:  "Джарвис спит",
    STATE_LISTENING: "Слушаю...",
    STATE_THINKING:  "Думаю...",
    STATE_EXECUTING: "Выполняю...",
}


# ==================== ОЧЕРЕДИ ====================
# GUI → голос: команды от пользователя (нажатия кнопки)
gui_to_voice = queue.Queue()
# Голос → GUI: обновления статуса
voice_to_gui = queue.Queue()


# ==================== GUI ====================
class JarvisApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Jarvis")
        self.geometry("400x700")
        self.configure(fg_color="#0d0d0d")
        self.resizable(False, False)

        self.current_state = STATE_SLEEPING

        self._build_ui()
        self._poll_status()

    def _build_ui(self):
        # --- Заголовок ---
        self.title_label = ctk.CTkLabel(
            self, text="Jarvis",
            font=("Arial", 30, "bold"),
            text_color="white"
        )
        self.title_label.pack(pady=(30, 10), padx=30, anchor="w")

        # --- Canvas для круга ---
        self.canvas = tk.Canvas(
            self, width=300, height=300,
            bg="#0d0d0d", highlightthickness=0
        )
        self.canvas.pack(pady=30)
        self.canvas.bind("<Button-1>", self._on_circle_click)

        self._draw_circle()

        # --- Статус ---
        self.status_label = ctk.CTkLabel(
            self, text=STATE_TEXTS[self.current_state],
            font=("Arial", 18),
            text_color="#999999"
        )
        self.status_label.pack(pady=(0, 30))

        # --- Лог последней команды ---
        self.log_frame = ctk.CTkFrame(
            self, fg_color="#1a1a1a",
            corner_radius=15, height=80
        )
        self.log_frame.pack(fill="x", padx=20, pady=10)
        self.log_frame.pack_propagate(False)

        self.log_label = ctk.CTkLabel(
            self.log_frame,
            text="Последняя команда: —",
            font=("Arial", 13),
            text_color="#aaaaaa"
        )
        self.log_label.pack(expand=True)

    def _draw_circle(self):
        self.canvas.delete("all")
        color = STATE_COLORS[self.current_state]
        cx, cy, r = 150, 150, 110

        # Свечение — несколько слоёв
        for i in range(15, 0, -1):
            offset = i * 3
            glow_color = self._blend(color, "#0d0d0d", i / 18)
            self.canvas.create_oval(
                cx - r - offset, cy - r - offset,
                cx + r + offset, cy + r + offset,
                fill=glow_color, outline=""
            )

        # Основной круг
        self.canvas.create_oval(
            cx - r, cy - r, cx + r, cy + r,
            fill=color, outline=""
        )

        # Иконка микрофона (упрощённая)
        # Тело микрофона — скруглённый прямоугольник
        self.canvas.create_oval(
            cx - 15, cy - 40, cx + 15, cy + 10,
            fill="white", outline=""
        )
        # Дуга-держатель
        self.canvas.create_arc(
            cx - 30, cy - 25, cx + 30, cy + 35,
            start=200, extent=140,
            style="arc", outline="white", width=5
        )
        # Ножка
        self.canvas.create_line(
            cx, cy + 35, cx, cy + 55,
            fill="white", width=5
        )

    def _blend(self, c1, c2, factor):
        """Смешивает два цвета. factor=0 → c2, factor=1 → c1."""
        def to_rgb(h):
            h = h.lstrip('#')
            return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))
        r1, g1, b1 = to_rgb(c1)
        r2, g2, b2 = to_rgb(c2)
        r = int(r2 + (r1 - r2) * factor)
        g = int(g2 + (g1 - g2) * factor)
        b = int(b2 + (b1 - b2) * factor)
        return f"#{r:02x}{g:02x}{b:02x}"

    def _on_circle_click(self, event):
        """Клик по кругу — переключить режим прослушивания."""
        gui_to_voice.put("toggle_listening")

    def set_state(self, state, text=None):
        self.current_state = state
        self.status_label.configure(text=text or STATE_TEXTS[state])
        self._draw_circle()

    def set_log(self, text):
        self.log_label.configure(text=f"Последняя команда: {text}")

    def _poll_status(self):
        """Каждые 100 мс проверяем очередь от голосового потока."""
        try:
            while True:
                msg = voice_to_gui.get_nowait()
                kind = msg.get("type")
                if kind == "state":
                    self.set_state(msg["state"], msg.get("text"))
                elif kind == "log":
                    self.set_log(msg["text"])
        except queue.Empty:
            pass
        self.after(100, self._poll_status)


# ==================== ЗАГЛУШКА ГОЛОСОВОГО ПОТОКА ====================
def voice_loop():
    """
    Здесь будет твой реальный голосовой цикл.
    Пока — заглушка: имитирует пробуждение по клику и смену состояний.
    """
    while True:
        # Ждём команду от GUI
        cmd = gui_to_voice.get()
        if cmd == "toggle_listening":
            # Смена состояний — как будто Джарвис «слушает → думает → выполняет»
            voice_to_gui.put({"type": "state", "state": STATE_LISTENING})
            voice_to_gui.put({"type": "log", "text": "Слушаю команду..."})
            time.sleep(2)

            voice_to_gui.put({"type": "state", "state": STATE_THINKING})
            time.sleep(1)

            voice_to_gui.put({"type": "state", "state": STATE_EXECUTING,
                              "text": "Открываю steam"})
            time.sleep(1.5)

            voice_to_gui.put({"type": "state", "state": STATE_SLEEPING})
            voice_to_gui.put({"type": "log", "text": "открой steam"})


# ==================== ЗАПУСК ====================
if __name__ == "__main__":
    # Голосовой поток — демон, чтобы завершался вместе с окном
    t = threading.Thread(target=voice_loop, daemon=True)
    t.start()

    # GUI в главном потоке
    app = JarvisApp()
    app.mainloop()