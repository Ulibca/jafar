import sounddevice as sd
import numpy as np
import speech_recognition as sr
import wave
import io
import os
import subprocess
import psutil
import win32gui
import win32con
import win32process
import time
import threading
import queue
import customtkinter as ctk
import tkinter as tk

# python -m pip install sounddevice numpy SpeechRecognition pyaudio psutil pywin32 customtkinter


# ==================== НАСТРОЙКИ ====================
SAMPLE_RATE = 16000
DURATION = 5  # секунд записи команды

BROWSER_PATH   = "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe"
BROWSER_PATH_2 = "C:/Program Files (x86)/Yandex/YandexBrowser/Application/browser.exe"


# ==================== СЛОВАРЬ ПРИЛОЖЕНИЙ ====================
apps = {
    "edge":   BROWSER_PATH,
    "яндекс": BROWSER_PATH_2,

    "steam":     "C:/Program Files (x86)/Steam/Steam.exe",
    "kimi":      "C:/Users/ADMIN F/AppData/Local/Programs/Kimi/Kimi.exe",
    "hub":       "C:/Program Files/FlyFrogLLC/Happ/Happ.exe",
    "хаб":       "C:/Program Files/FlyFrogLLC/Happ/Happ.exe",
    "teamspeak": "C:/Users/ADMIN F/AppData/Local/Programs/TeamSpeak/TeamSpeak.exe",
    "мизери":    "steam://rungameid/2119830",
    "мызери":    "steam://rungameid/2119830",
    "калькулятор": "calc.exe",

    "ютуб":      "https://www.youtube.com",
    "github":    "https://github.com/Ulibca",
    "музыка":    "https://music.yandex.ru",
    "ivi":       "https://www.ivi.ru/programs",
    "telegram":  "https://web.telegram.org/k/#@Koteikin69",
}


# ==================== СОСТОЯНИЯ ====================
STATE_SLEEPING  = "sleeping"
STATE_LISTENING = "listening"
STATE_THINKING  = "thinking"
STATE_EXECUTING = "executing"

STATE_COLORS = {
    STATE_SLEEPING:  "#3a3a5c",
    STATE_LISTENING: "#7c5cff",
    STATE_THINKING:  "#ffb84d",
    STATE_EXECUTING: "#4dff88",
}
STATE_TEXTS = {
    STATE_SLEEPING:  "Джарвис спит",
    STATE_LISTENING: "Слушаю...",
    STATE_THINKING:  "Думаю...",
    STATE_EXECUTING: "Выполняю...",
}


# ==================== ОЧЕРЕДИ ====================
gui_to_voice = queue.Queue()   # GUI → голос (нажатия кнопок, выход)
voice_to_gui = queue.Queue()   # голос → GUI (статус, лог)


# ==================== ЗАПИСЬ АУДИО ====================
def record_audio():
    audio_data = sd.rec(
        int(DURATION * SAMPLE_RATE),
        samplerate=SAMPLE_RATE,
        channels=1,
        dtype='int16'
    )
    sd.wait()

    with io.BytesIO() as wav_io:
        with wave.open(wav_io, 'wb') as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(SAMPLE_RATE)
            wf.writeframes(audio_data.tobytes())
        wav_io.seek(0)
        return sr.AudioData(wav_io.read(), SAMPLE_RATE, 2)


# ==================== ОТКРЫТИЕ ====================
def open_app(name):
    path = apps.get(name.lower())
    if not path:
        return f"Приложение '{name}' не найдено."

    if path.startswith('steam://'):
        os.startfile(path)
        return f"Запускаю {name} через Steam"

    if path.startswith("http"):
        try:
            subprocess.Popen([BROWSER_PATH, path])
            return f"Открываю сайт {name}"
        except Exception as e:
            return f"Не удалось открыть сайт: {e}"
    else:
        try:
            subprocess.Popen([path])
            return f"Открываю приложение {name}"
        except Exception as e:
            return f"Не удалось запустить: {e}"


# ==================== ЗАКРЫТИЕ ====================
def _graceful_close(process_name, app_path):
    process_name = process_name.lower()

    if process_name == "steam.exe":
        try:
            subprocess.run([app_path, "-shutdown"], timeout=10)
            for _ in range(20):
                time.sleep(0.5)
                if not any(
                    p.info.get('name', '').lower() == process_name
                    for p in psutil.process_iter(['name'])
                ):
                    return True, "Steam закрыт ✅"
            return False, "Steam не завершился"
        except Exception as e:
            return False, f"Ошибка -shutdown: {e}"

    closed = False

    def enum_handler(hwnd, _):
        nonlocal closed
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        try:
            proc = psutil.Process(pid)
            if proc.name().lower() == process_name:
                win32gui.PostMessage(hwnd, win32con.WM_CLOSE, 0, 0)
                closed = True
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    win32gui.EnumWindows(enum_handler, None)
    return closed, ""


def _has_visible_windows(process_name):
    process_name = process_name.lower()
    found = False

    def enum_handler(hwnd, _):
        nonlocal found
        if not win32gui.IsWindowVisible(hwnd):
            return
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        try:
            proc = psutil.Process(pid)
            if proc.name().lower() == process_name:
                found = True
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    win32gui.EnumWindows(enum_handler, None)
    return found


def close_app(name):
    """Возвращает строку-отчёт для UI."""
    path = apps.get(name.lower())
    if not path:
        return f"Приложение '{name}' не найдено."

    if path.startswith("http"):
        return f"'{name}' — это сайт, я его не закрываю."

    if path.startswith("steam://"):
        return f"'{name}' — это игра из Steam, я её пока не умею закрывать."

    process_name = os.path.basename(path).lower()

    ok, msg = _graceful_close(process_name, path)
    if msg:
        return msg
    if not ok:
        return f"У {name} нет видимых окон — возможно, не запущен."

    for _ in range(20):
        time.sleep(0.5)
        if not _has_visible_windows(process_name):
            return f"{name} закрылся ✅"

    return f"{name} не закрылся (окна всё ещё видны)."


# ==================== ГОЛОСОВОЙ ПОТОК ====================
def voice_loop():
    """
    Работает в фоне. Общается с GUI через очереди:
      voice_to_gui: {"type": "state", "state": ..., "text": ...}
                    {"type": "log",   "text": ...}
    """
    r = sr.Recognizer()

    voice_to_gui.put({"type": "state", "state": STATE_SLEEPING,
                      "text": "Джарвис спит"})

    while True:
        # 1. Сообщаем: слушаю
        voice_to_gui.put({"type": "state", "state": STATE_LISTENING})
        voice_to_gui.put({"type": "log", "text": "Записываю 5 секунд..."})

        try:
            audio = record_audio()

            # 2. Сообщаем: думаю
            voice_to_gui.put({"type": "state", "state": STATE_THINKING})

            text = r.recognize_google(audio, language="ru_RU").lower()
            print(f"Вы сказали: {text}")
            voice_to_gui.put({"type": "log", "text": f"Вы: {text}"})

            # Выход
            if text in ("стоп", "выход", "пока", "заверши", "закончи", "закончим"):
                voice_to_gui.put({"type": "state", "state": STATE_SLEEPING,
                                  "text": "До свидания!"})
                voice_to_gui.put({"type": "log", "text": "Завершение работы"})
                break

            # Команды
            result = ""
            if text.startswith("джарвис открой "):
                name = text.replace("джарвис открой ", "").strip()
                voice_to_gui.put({"type": "state", "state": STATE_EXECUTING,
                                  "text": f"Открываю {name}"})
                result = open_app(name)
            elif text.startswith("джарвис закрой "):
                name = text.replace("джарвис закрой ", "").strip()
                voice_to_gui.put({"type": "state", "state": STATE_EXECUTING,
                                  "text": f"Закрываю {name}"})
                result = close_app(name)
            else:
                result = "Команда не распознана."

            print(result)
            voice_to_gui.put({"type": "log", "text": result})

        except sr.UnknownValueError:
            voice_to_gui.put({"type": "log", "text": "Не расслышал"})
        except sr.RequestError:
            voice_to_gui.put({"type": "log", "text": "Ошибка интернета"})
        except Exception as e:
            voice_to_gui.put({"type": "log", "text": f"Ошибка: {e}"})

        # Возвращаемся в сон
        voice_to_gui.put({"type": "state", "state": STATE_SLEEPING})


# ==================== GUI ====================
class JarvisApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Jarvis")
        self.geometry("400x700")
        self.configure(fg_color="#0d0d0d")
        self.resizable(False, False)

        self.current_state = STATE_SLEEPING
        self._build_ui()
        self._poll_status()

        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        self.title_label = ctk.CTkLabel(
            self, text="Jarvis",
            font=("Arial", 30, "bold"),
            text_color="white"
        )
        self.title_label.pack(pady=(30, 10), padx=30, anchor="w")

        self.canvas = tk.Canvas(
            self, width=300, height=300,
            bg="#0d0d0d", highlightthickness=0
        )
        self.canvas.pack(pady=30)

        self._draw_circle()

        self.status_label = ctk.CTkLabel(
            self, text=STATE_TEXTS[self.current_state],
            font=("Arial", 18), text_color="#999999"
        )
        self.status_label.pack(pady=(0, 30))

        self.log_frame = ctk.CTkFrame(
            self, fg_color="#1a1a1a", corner_radius=15, height=100
        )
        self.log_frame.pack(fill="x", padx=20, pady=10)
        self.log_frame.pack_propagate(False)

        self.log_label = ctk.CTkLabel(
            self.log_frame, text="Последняя команда: —",
            font=("Arial", 13), text_color="#aaaaaa",
            wraplength=340, justify="left"
        )
        self.log_label.pack(expand=True, padx=10)

    def _draw_circle(self):
        self.canvas.delete("all")
        color = STATE_COLORS[self.current_state]
        cx, cy, r = 150, 150, 110

        for i in range(15, 0, -1):
            offset = i * 3
            glow_color = self._blend(color, "#0d0d0d", i / 18)
            self.canvas.create_oval(
                cx - r - offset, cy - r - offset,
                cx + r + offset, cy + r + offset,
                fill=glow_color, outline=""
            )

        self.canvas.create_oval(
            cx - r, cy - r, cx + r, cy + r,
            fill=color, outline=""
        )

        # Иконка микрофона
        self.canvas.create_oval(cx - 15, cy - 40, cx + 15, cy + 10,
                                fill="white", outline="")
        self.canvas.create_arc(cx - 30, cy - 25, cx + 30, cy + 35,
                               start=200, extent=140,
                               style="arc", outline="white", width=5)
        self.canvas.create_line(cx, cy + 35, cx, cy + 55,
                                fill="white", width=5)

    def _blend(self, c1, c2, factor):
        def to_rgb(h):
            h = h.lstrip('#')
            return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))
        r1, g1, b1 = to_rgb(c1)
        r2, g2, b2 = to_rgb(c2)
        r = int(r2 + (r1 - r2) * factor)
        g = int(g2 + (g1 - g2) * factor)
        b = int(b2 + (b1 - b2) * factor)
        return f"#{r:02x}{g:02x}{b:02x}"

    def set_state(self, state, text=None):
        self.current_state = state
        self.status_label.configure(text=text or STATE_TEXTS[state])
        self._draw_circle()

    def set_log(self, text):
        self.log_label.configure(text=f"{text}")

    def _poll_status(self):
        """Каждые 100 мс читаем очередь от голосового потока."""
        try:
            while True:
                msg = voice_to_gui.get_nowait()
                kind = msg.get("type")
                if kind == "state":
                    self.set_state(msg["state"], msg.get("text"))
                elif kind == "log":
                    self.set_log(msg["text"])
        except queue.Empty:
            pass
        self.after(100, self._poll_status)

    def _on_close(self):
        """Корректное завершение."""
        gui_to_voice.put("quit")
        self.destroy()


# ==================== ЗАПУСК ====================
if __name__ == "__main__":
    # Голосовой поток — daemon, умрёт вместе с процессом
    t = threading.Thread(target=voice_loop, daemon=True)
    t.start()

    # GUI в главном потоке
    app = JarvisApp()
    app.mainloop()